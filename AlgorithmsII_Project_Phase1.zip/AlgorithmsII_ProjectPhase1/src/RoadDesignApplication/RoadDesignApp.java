package RoadDesignApplication;

/*
 * CPCS324 Project Part 1
 * Fall 2022 
 * Juri Alsubhi, Shahad Hanbuli, 
 *
 */

import GraphFramework.*;
import java.io.*;
import java.util.*;

public class RoadDesignApp extends Graph {

    static Graph graph = new RoadDesignApp();

    public static void main(String[] args) throws FileNotFoundException {

        // READ FROM FILE
        File file = new File("graph.txt");

        graph.readGraphFromFile(file);

        // Requirment I
        System.out.println("City Road Map...");
        MSTAlgorithm cityMap = new KruskalAlg(graph);
        ((KruskalAlg) cityMap).Kruskal();
        cityMap.displayResultingMST();

        cityMap = new PQPrimAlg(graph);
        ((PQPrimAlg) cityMap).PQPrim();
        cityMap.displayResultingMST();

        /*
        • n=1000 and m={10000, 15000, 25000}
        • n=5000 and m={15000, 25000}
        • n=10000 and m={15000, 25000}
         */
        
        // Requirment II  
//        int[] N = {1000, 5000, 10000};
//        int[] M = {15000, 25000};
//
//        graph.makeGraph(10000, 25000); // first set 
//
//        cityMap = new KruskalAlg(graph);
//        ((KruskalAlg) cityMap).Kruskal();
//        cityMap.displayResultingMST();
//
//        cityMap = new PQPrimAlg(graph);
//        ((PQPrimAlg) cityMap).PQPrim();
//        cityMap.displayResultingMST();
//        
//        
//        for (int i = 0; i < N.length; i++) {
//            for (int j = 0; j < M.length; j++) {
//
//                graph.makeGraph(N[i], M[j]);
//
//                cityMap = new KruskalAlg(graph);
//                ((KruskalAlg) cityMap).Kruskal();
//                cityMap.displayResultingMST();
//
//                cityMap = new PQPrimAlg(graph);
//                ((PQPrimAlg) cityMap).PQPrim();
//                cityMap.displayResultingMST();
//            }
//        }

    }

    @Override
    public Graph makeGraph(int verticesNo, int edgeNo) {
        // CREATE GRAPH OBJECT
        Random random = new Random();

        // ------------------------------------------- ## STEP 1 ## ---------------------------------------------------
        // CREATE VERTICES AND INITIALIZE THE LABELS
        for (int i = 0; i < verticesNo; i++) {
            Vertex ver = new House(i);
            // INCREMENT NUM OF VERTICES IN GRAPH
            graph.verticesNo++;
            Vertex.adjList.add(new LinkedList<>());
            graph.verList.add(ver);
        }// END FOR LOOP 

        // ------------------------------------------- ## STEP 2 ## ---------------------------------------------------
        // CONNECT ALL VERTICES 
        for (int i = 0; i < verticesNo - 1; i++) {

            // GENERATE RANDOM VALUE FOR WEIGHT
            int weight = random.nextInt(50) + 1;

            // ------------------------------------------- ASCENDING ORDER  ---------------------------------------------------
            if ((i + 1) > verticesNo - 1) {
                // REACHED LAST VERTEX, CONNECT WITH FIRST VERTEX
                addEdge(graph.verList.get(i), graph.verList.get(0), weight);

                // INCREMENT NUM OF EDGES IN GRAPH
                graph.edgeNo++;
                continue;
            }// END IF

            // CREATE EDGE BETWEEN VERTICES 
            addEdge(graph.verList.get(i), graph.verList.get(i + 1), weight);

            // INCREMENT NUM OF EDGES IN GRAPH
            graph.edgeNo++;

            if (!graph.isDigraph) {

                // CREATE EDGE BETWEEN VERTICES
                addEdge(graph.verList.get(i + 1), graph.verList.get(i), weight);

                // INCREMENT NUM OF EDGES IN GRAPH
                graph.edgeNo++;
            }// END IF 
        }// END FOR LOOP 

        // ------------------------------------------- ## STEP 3 ## ---------------------------------------------------
        // CREATE REMAINING EDGES RANDOMLY BETWEEN VERTICES
        // CALCULATE REMAINING EDGES
        int remEdge = edgeNo - (verticesNo - 1);

        // CONNECT VERTICES RANDOMLY 
        for (int i = 0; i < remEdge; i++) {

            // GENERATE RANDOM VALUE FOR SRC AND DEST VERTICES
            int srcVert = random.nextInt(graph.verticesNo);
            int destVert = random.nextInt(graph.verticesNo);

            // CHECK TO AVOID FOR DUPLICATE EDGES
            if (destVert == srcVert || CheckEdge(srcVert, destVert)) { // [5]
                i--;
                continue;
            }// END IF

            // GENERATE RANDOM VALUE FOR WEIGHT
            int weight = random.nextInt(50) + 1;
            // CREATE EDGE BETWEEN VERTICES
            addEdge(graph.verList.get(srcVert), graph.verList.get(destVert), weight);

            // INCREMENT NUM OF EDGES IN GRAPH
            graph.edgeNo++;

            // IF GRAPH IS UNDIRECTED
            if (!graph.isDigraph) {

                // CREATE EDGE BETWEEN VERTICES
                addEdge(graph.verList.get(destVert), graph.verList.get(srcVert), weight);

                // INCREMENT NUM OF EDGES IN GRAPH
                graph.edgeNo++;
            }// END IF 
        }// END FOR LOOP

        // RETURN GRAPH
        return graph; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Graph readGraphFromFile(File filename) {

        try ( Scanner in = new Scanner(filename)) {

            in.next();
            isDigraph = (in.nextInt() == 1);

            verticesNo = in.nextInt();
            edgeNo = in.nextInt();

            for (int i = 0, ver = 0; i < edgeNo; i++) {                                                              // A B 1 -- A C 

                char srcName = in.next().charAt(0);
                char desName = in.next().charAt(0);
                int edgeWeight = in.nextInt();

                // search for src
                Vertex src = searchVertex(srcName);
                
                // search for dest
                Vertex dest = searchVertex(desName);

                // create house object for the new house
                if (src == null) {
                    // src ver
                    src = new House(ver++, srcName);
                    Vertex.adjList.add(new LinkedList<>());
                    graph.verList.add(src);
                }

                if (dest == null) {
                    
                    dest = new House(ver++, desName);
                    Vertex.adjList.add(new LinkedList<>());
                    graph.verList.add(dest);
                }

                addEdge(src, dest, edgeWeight);
            }

        } catch (FileNotFoundException e) {
            System.out.println("File Not Found");
        }

        return graph;
    }

    @Override
    public void addEdge(Vertex srcVer, Vertex destVer, int weight) {
        Edge edge = new Road(srcVer, destVer, weight);
        edge.parent = new House(-1); 
        Vertex.adjList.get(srcVer.label).add(edge);
        Edge.totalEdges.add(edge);
    }

    public Vertex searchVertex(char name) {

        for (int i = 0; i < verList.size(); i++) {
            if (((House) verList.get(i)).getHouseName() == name) {
                return verList.get(i);
            }
        }

        return null;
    }
}
