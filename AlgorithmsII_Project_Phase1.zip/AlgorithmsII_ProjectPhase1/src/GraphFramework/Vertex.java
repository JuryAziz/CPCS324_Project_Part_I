package GraphFramework;

import java.util.ArrayList;
import java.util.LinkedList;


public class Vertex implements Comparable<Vertex>{
    
    // DATA FIELD
    public int label;


    public int parent = -1; // LABEL OF PARENT VERTEX -> INITIAL VALUE -1 
    public int rank = 0;
    public int key = Integer.MAX_VALUE;
    
    static public ArrayList<LinkedList<Edge>> adjList = new ArrayList<>(); // ADJACENCY LIST

    public Vertex(){

    }

    public Vertex(int label){
        this.label = label;
    }

    public String displayInfo(){
        return "Vertex: " + label;
    }

    @Override
    public int compareTo(Vertex o) {
        return (this.key - o.key);
    }
    
}
