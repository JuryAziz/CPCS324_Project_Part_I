package GraphFramework;


import java.io.*;
import java.util.*;

public class Graph {

    public int verticesNo;
    public int edgeNo;
    public boolean isDigraph = false;
    public ArrayList<Vertex> verList = new ArrayList<>();



    public Graph() {

    }

    public Graph(int verticesNo, int edgeNo, boolean isDigraph) {
        this.verticesNo = verticesNo;
        this.edgeNo = edgeNo;
        this.isDigraph = isDigraph;
        verList = new ArrayList<>(verticesNo);
    }
    

    public Graph readGraphFromFile(File filename){
        
        try ( Scanner in = new Scanner(filename) ) {

            in.next();
            isDigraph = (in.nextInt() == 1);

            verticesNo = in.nextInt();
            edgeNo = in.nextInt();

            for (int i = 0; i < edgeNo; i++) {                                                              // A B 1 -- A C 

                int srcLabel = in.nextInt();
                int destLabel = in.nextInt();
                int edgeWeight = in.nextInt();

                // search for src
                Vertex src = searchVertex(srcLabel);
                
                // search for dest
                Vertex dest = searchVertex(destLabel);

                // create house object for the new house
                if (src == null) {
                    // src ver
                    src = new Vertex(srcLabel);
                    Vertex.adjList.add(new LinkedList<>());
                    verList.add(src);
                }

                if (dest == null) {
                    
                    dest = new Vertex(destLabel);
                    Vertex.adjList.add(new LinkedList<>());
                    verList.add(dest);
                }

                addEdge(src, dest, edgeWeight);
            }

        } catch (FileNotFoundException e) {
            System.out.println("File Not Found");
        }

        return this;
    }

    // ------------------------------------------- makeGraph ---------------------------------------------------
    /**
     * this function takes as parameters the number of vertices and the number
     * of edges.It is responsible for creating a graph object with the specified
     * parameters and randomly initializes the vertices’ labels, creating edges
     * that connects the created vertices randomly and assigning them random
     * weights.Make sure that the resulting graph is connected.
     *
     * @param verticesNo
     * @param edgeNo
     * @return
     */
    public Graph makeGraph(int verticesNo, int edgeNo) {


        Graph graph = new Graph(); 
        Random random = new Random();

        // ------------------------------------------- ## STEP 1 ## ---------------------------------------------------
        // CREATE VERTICES AND INITIALIZE THE LABELS
        for (int i = 0; i < verticesNo; i++) {
            Vertex ver = new Vertex(i);
            // INCREMENT NUM OF VERTICES IN GRAPH
            graph.verticesNo++; 
            Vertex.adjList.add(new LinkedList<>());
            graph.verList.add(ver);
        }// END FOR LOOP 

        // ------------------------------------------- ## STEP 2 ## ---------------------------------------------------
        // CONNECT ALL VERTICES 
        for (int i = 0; i < verticesNo - 1; i++) {

            // GENERATE RANDOM VALUE FOR WEIGHT
            int weight = random.nextInt(50) + 1;

            // ------------------------------------------- ASCENDING ORDER  ---------------------------------------------------
            if ((i + 1) > verticesNo - 1) {
                // REACHED LAST VERTEX, CONNECT WITH FIRST VERTEX
                addEdge(graph.verList.get(i), graph.verList.get(0), weight);

                // INCREMENT NUM OF EDGES IN GRAPH
                graph.edgeNo++; 
                continue;
            }// END IF

            // CREATE EDGE BETWEEN VERTICES 
            addEdge(graph.verList.get(i), graph.verList.get(i + 1), weight);

            // INCREMENT NUM OF EDGES IN GRAPH
            graph.edgeNo++;

            if (!graph.isDigraph) {

                // CREATE EDGE BETWEEN VERTICES
                addEdge(graph.verList.get(i + 1), graph.verList.get(i), weight);

                // INCREMENT NUM OF EDGES IN GRAPH
                graph.edgeNo++;
            }// END IF 
        }// END FOR LOOP 

        // ------------------------------------------- ## STEP 3 ## ---------------------------------------------------
        // CREATE REMAINING EDGES RANDOMLY BETWEEN VERTICES
        // CALCULATE REMAINING EDGES
        int remEdge = edgeNo - (verticesNo - 1);

        // CONNECT VERTICES RANDOMLY 
        for (int i = 0; i < remEdge; i++) {
            
            // GENERATE RANDOM VALUE FOR SRC AND DEST VERTICES
            int srcVert = random.nextInt(graph.verticesNo);
            int destVert = random.nextInt(graph.verticesNo);

            // CHECK TO AVOID FOR DUPLICATE EDGES
            if (destVert == srcVert || CheckEdge(srcVert, destVert)) { // [5]
                i--;
                continue;
            }// END IF

            // GENERATE RANDOM VALUE FOR WEIGHT
            int weight = random.nextInt(50) + 1;
            // CREATE EDGE BETWEEN VERTICES
            addEdge(graph.verList.get(srcVert), graph.verList.get(destVert), weight);

            // INCREMENT NUM OF EDGES IN GRAPH
            graph.edgeNo++;

            // IF GRAPH IS UNDIRECTED
            if (!graph.isDigraph) {

                // CREATE EDGE BETWEEN VERTICES
                addEdge(graph.verList.get(destVert), graph.verList.get(srcVert), weight);

                // INCREMENT NUM OF EDGES IN GRAPH
                graph.edgeNo++;
            }// END IF 
        }// END FOR LOOP

        // RETURN GRAPH
        return graph;
    }// END METHOD

    // ------------------------------------------- addEdge ---------------------------------------------------
    public void addEdge(Vertex srcVer, Vertex destVer, int weight) {

        Edge edgeObj = new Edge(srcVer, destVer, weight);
        edgeObj.parent = new Vertex(-1);
        Vertex.adjList.get(srcVer.label).add(edgeObj);
        Edge.totalEdges.add(edgeObj);

    }// END addEdge METHOD
     
    // ------------------------------------------- CheckEdge ---------------------------------------------------
    public boolean CheckEdge(int src, int dest) {

        for (int i = 0; i < Vertex.adjList.size(); i++) {
            for (int j = 0; j < Vertex.adjList.get(i).size(); j++) {
                Edge temp = Vertex.adjList.get(i).get(j);
                if (temp.destVer.label == dest && temp.srcVer.label == src) {
                    return true;
                }// END IF
            }// END FOR LOOP J
        }// END FOR LOOP I
        
        // IF THERE IN NO MATCH RETURN FALSE
        return false;
    }// END METHOD



    private Vertex searchVertex(int src) {
        for (int i = 0; i < verList.size(); i++) {
            if (verList.get(i).label == src) {
                return verList.get(i);
            }
        }
        return null;
    }
    
}// END CLASS
