package GraphFramework;
import java.util.*;

public class KruskalAlg extends MSTAlgorithm {

    public KruskalAlg() {
    }

    public KruskalAlg(Graph graph) {
        super(graph);
    }
    
    
    public int findParent(Vertex vertex) {
        // root vertex
        if (vertex.parent == -1) {
            return vertex.label;
        }
        // recursion
        return vertex.parent = findParent(graph.verList.get(vertex.parent));
    }


    public boolean isCycle(Vertex A, Vertex B) {
        return findParent(A) == findParent(B);
    }


    public void union(Vertex A, Vertex B) {

        // HAVING SAME RANK , RANK OF NEW PARENT DECREASE
        if (A.rank == B.rank) {
            int parent = findParent(A);
            graph.verList.get(findParent(B)).parent = parent;
            A.rank++;
        }

        // HAVING DIFFERENT RANK, RANK DOESN'T CHANGE
        // LOWER RANK PARENT WILL BE CHILD OF HIGHER RANK PARENT
        else if (A.rank > B.rank) {
            int parent = findParent(B);
            graph.verList.get(findParent(A)).parent = parent;

        } else if (A.rank < B.rank){
            int parent = findParent(A);
            graph.verList.get(findParent(B)).parent = parent;
        }
        
    }

   
    public void Kruskal() {
        
        long start = System.currentTimeMillis();

        int eCounter = 0; // EDGE COUNTER
        int k = 0;// LOOP COUNTER

        // SORT EDGES
        Collections.sort(Edge.totalEdges);

        while (eCounter < graph.verList.size() - 1) {
            
            // REACH LAST EDGE IN ARRAY
            if (k == Edge.totalEdges.size()) {
                break;
            }

            Vertex src = Edge.totalEdges.get(k).srcVer;
            Vertex dest = Edge.totalEdges.get(k).destVer;

            if (isCycle(src, dest)) {
                k++;
                continue;
            }
            
            union(src, dest); 
            MSTResultList.add(Edge.totalEdges.get(k));
            k++;
            eCounter++;
        }

        long finish = System.currentTimeMillis();
        
        totalTime = finish - start;
    }

    @Override
    public void displayResultingMST() {
        
        int minimumCost = 0;
        
        System.out.println("\nKruskal's Algorithm: ");
        
        for (int i = 0; i < MSTResultList.size() && MSTResultList.size() < 10; i++) {
            minimumCost += MSTResultList.get(i).weight;
            System.out.println(MSTResultList.get(i).srcVer.displayInfo() + " - " + MSTResultList.get(i).destVer.displayInfo() + " : " + MSTResultList.get(i).displayInfo());
            
        }
        
        System.out.println("\tMinimum Cost Spanning Tree = " + minimumCost);
        System.out.println("\tTotal runtime = " + totalTime + " msec");

        MSTResultList.clear();
    }




}

