package GraphFramework;

import java.util.*;

public class Edge implements Comparable<Edge> {

    public Vertex srcVer;
    public Vertex destVer;
    public Vertex parent;
    public int weight;
    //public char[] toString;

    // arraylist of all edges
    public static ArrayList<Edge> totalEdges = new ArrayList<Edge>();

    public Edge(Vertex srcVer, Vertex destVer, int weight) {
        this.srcVer = srcVer;
        this.destVer = destVer;
        this.weight = weight;
    }

    
    public String displayInfo() {
        return (destVer.label + "(" + srcVer.label + "," + weight + ") ");
    }

    @Override
    public int compareTo(Edge o) {
        return (this.weight - o.weight);
    }

}
