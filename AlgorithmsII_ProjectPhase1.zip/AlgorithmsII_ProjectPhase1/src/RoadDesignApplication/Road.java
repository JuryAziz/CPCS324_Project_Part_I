package RoadDesignApplication;

import GraphFramework.*;

public class Road extends Edge {
    
    private int roadSize;
    private String roadName;
    static int count = 1;


    public Road(Vertex srcVer, Vertex destVer, int weight) {
        super(srcVer, destVer, weight);
        this.roadSize = 3*weight;
        roadName = "X"+ count++;

    }

    @Override
    public String displayInfo(){
        return " Road " + roadName + " with the size " + roadSize;
   }

}
