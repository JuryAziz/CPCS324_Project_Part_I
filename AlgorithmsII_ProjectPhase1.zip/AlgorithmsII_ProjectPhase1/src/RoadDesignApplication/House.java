package RoadDesignApplication;

import GraphFramework.*;

public class House extends Vertex{
    
  private char houseName;

    // CONSTRUCTOR
    public House() {

    }
    
    public House(int label) {
      super(label);
    }
    
    public House(int label, char houseName) {
      super(label);
      this.houseName = houseName;
    }
   
    @Override
    public String displayInfo(){
      return " House Name " + this.houseName;
    }

    public char getHouseName(){
      return houseName;
    }

}
