package GraphFramework;
import java.util.*;

public class KruskalAlg extends MSTAlgorithm {

    public KruskalAlg() {
    }

    public KruskalAlg(Graph graph) {
        super(graph);
    }
    
    // --------------------- findParent ---------------------
    public int findParent(Vertex vertex) {
        if (vertex.parent == -1) {
            return vertex.label;
        } // END IF
        
        return vertex.parent = findParent(graph.verList.get(vertex.parent));
    }// END FIND PARENT METHOD

    // --------------------- isCycle ---------------------
    public boolean isCycle(Vertex A, Vertex B) {
        if (findParent(A) == findParent(B)) {
            return true;
        } // END IF
        return false;
    }// END IS CYCLE METHOD

    // --------------------- union ---------------------
    public void union(Vertex A, Vertex B) {

        // HAVING SAME RANK , RANK OF NEW PARENT DECREASE
        if (A.rank == B.rank) {
            int parent = findParent(A);
            graph.verList.get(findParent(B)).parent = parent;
            A.rank++;
        }

        // HAVING DIFFERENT RANK, RANK DOESN'T CHANGE
        // LOWER RANK PARENT WILL BE CHILD OF HIGHER RANK PARENT
        else if (A.rank > B.rank) {
            int parent = findParent(B);
            graph.verList.get(findParent(A)).parent = parent;

        } else if (A.rank < B.rank){
            int parent = findParent(A);
            graph.verList.get(findParent(B)).parent = parent;
        }// END IF ELSE
        
    }// END UNION METHOD

    // ------------------------------------------- Kruskal ---------------------------------------------------
    public void Kruskal() {
        // START TIME
        long start = System.currentTimeMillis();

        int eCounter = 0; // EDGE COUNTER
        int k = 0;// LOOP COUNTER

        // SORT EDGES
        Collections.sort(Edge.totalEdges);

        while (eCounter < graph.verList.size() - 1) {
            
            // REACH LAST EDGE IN ARRAY
            if (k == Edge.totalEdges.size()) {
                break;
            }// END IF

            Vertex src = Edge.totalEdges.get(k).srcVer;
            Vertex dest = Edge.totalEdges.get(k).destVer;

            if (isCycle(src, dest)) {
                k++;
                continue;
            }// END IF
            
            union(src, dest); 
            MSTResultList.add(Edge.totalEdges.get(k));
            k++;
            eCounter++;
        }// END WHILE LOOP

        // FINISH TIME
        long finish = System.currentTimeMillis();
        totalTime = finish - start;
    }// END METHOD

    @Override
    public void displayResultingMST() {

        int minimumCost = 0;

        System.out.println("\nKruskal's Algorithm: ");

        for (int i = 0; i < MSTResultList.size(); i++) {
            minimumCost += MSTResultList.get(i).weight;
            if (MSTResultList.size() < 10) {
                System.out.println(MSTResultList.get(i).srcVer.displayInfo() + " - " + MSTResultList.get(i).destVer.displayInfo() + " : " + MSTResultList.get(i).displayInfo());
            }
        }

        System.out.println("\tMinimum Cost Spanning Tree = " + minimumCost);
        System.out.println("\tTotal runtime = " + totalTime + " msec");

        MSTResultList.clear();
    }

}
