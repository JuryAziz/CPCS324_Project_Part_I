package GraphFramework;

import java.util.*;

public class PQPrimAlg extends MSTAlgorithm {

    // CREATE AN EMPTY PRIORITY QUEUE
    // Map (key - value) -> key = key(weight), value = vertex label
    PriorityQueue<Map.Entry<Integer, Integer>> priorityQueue = new PriorityQueue<>(
            graph.verList.size(), (Map.Entry<Integer, Integer> m1, Map.Entry<Integer, Integer> m2)
            -> {
        int key1 = m1.getKey();
        int key2 = m2.getKey();
        return key1 - key2;
    });

    public PQPrimAlg() {
    }

    public PQPrimAlg(Graph graph) {
        super(graph);
    }

    boolean inMST[] = new boolean[graph.verList.size()];
    int key[] = new int[graph.verList.size()];

    public void PQPrim() {

        long start = System.currentTimeMillis();

        // INITIALIZE KEYS OF ALL VERTICES AS INFINITE, PARENT OF EVERY VERTEX AS -1 AND
        // NOT PART OF MST YET.
        for (int i = 0; i < graph.verList.size(); i++) {
            key[i] = Integer.MAX_VALUE;
            graph.verList.get(i).parent = -1;
            inMST[i] = false;
        }

        // INSERT AN ENTRY REPRESENTING A MAPPING INTO PQ AND MAKE ITS KEY AS 0
        key[0] = 0;
        priorityQueue.add(new AbstractMap.SimpleEntry<>(key[0], 0));

        // LOOP WHILE QUEUE IS NOT EMPTY 
        while (!priorityQueue.isEmpty()) {

            // EXTRACT MINIMUM KEY VERTEX FROM PQ.
            Map.Entry<Integer, Integer> tempVer = priorityQueue.poll(); // u

            // INCLUDE IT IN MST
            inMST[tempVer.getValue()] = true;

            // ITERATE THROUGH ALL THE ADJACENT VERTICES OF ABOVE VERTEX u
            for (int i = 0; i < Vertex.adjList.get(tempVer.getValue()).size(); i++) {

                Vertex destVer = Vertex.adjList.get(tempVer.getValue()).get(i).destVer; // v
                int tempWeight = Vertex.adjList.get(tempVer.getValue()).get(i).weight; // v - u weight

                // IF VERTEX v IS NOT IN MST 
                if (inMST[destVer.label] == false && key[destVer.label] > tempWeight) {

                    // UPDATE KEY
                    key[destVer.label] = tempWeight;

                    // CREATE A MAP OBJECT WITH VERTEX V AND KEY = U-V WEIGHT AND INSERT IT INTO
                    // PRIORITY QUEUE.
                    priorityQueue.add(new AbstractMap.SimpleEntry<>(key[destVer.label], destVer.label));

                    // UPDATE PARENT
                    destVer.parent = tempVer.getValue();
                }
            }
        }

        for (int i = 0; i < graph.verList.size(); i++) {
            Vertex tempVer = graph.verList.get(i);

            for (int j = 0; j < Vertex.adjList.get(i).size(); j++) {
                Edge temp = Vertex.adjList.get(i).get(j);
                if (temp.srcVer.parent == tempVer.parent && temp.destVer.parent == tempVer.label) {
                    MSTResultList.add(temp);
                }
            }
        }

        long finish = System.currentTimeMillis();
        totalTime = finish - start;
    }

    @Override
    public void displayResultingMST() {

        int minimumCost = 0;

        System.out.println("\nPrim's Algorithm (Priority Queue): ");

        for (int i = 0; i < MSTResultList.size(); i++) {
            minimumCost += MSTResultList.get(i).weight;
            if (MSTResultList.size() < 10) {

                System.out.println(MSTResultList.get(i).srcVer.displayInfo() + " - " + MSTResultList.get(i).destVer.displayInfo() + " : " + MSTResultList.get(i).displayInfo());
            }
        }

        System.out.println("\tMinimum Cost Spanning Tree = " + minimumCost);
        System.out.println("\tTotal runtime = " + totalTime + " msec");

        MSTResultList.clear();
    }
}// END CLASS
